'use strict';

// RX TOPUP Telegram order bot. Secrets are supplied only through Render env vars.
const fs = require('fs');
const path = require('path');

module.exports = function startRxTelegramBot(options) {
  const token = String(process.env.RX_TELEGRAM_BOT_TOKEN || '').trim();
  const adminId = String(process.env.RX_TELEGRAM_ADMIN_ID || '8961961969').trim();
  if (!token) {
    console.log('Telegram bot: disabled (set RX_TELEGRAM_BOT_TOKEN in Render)');
    return;
  }

  const root = options.rootDir;
  const dataDir = options.dataDir;
  const htmlPath = path.join(root, 'FFX.html');
  const ordersPath = path.join(dataDir, 'telegram-orders.json');
  const sessions = new Map();
  let offset = 0;
  let polling = false;

  const categories = [
    { id: 'mysteryPkGrid', title: '🎁 Mystery Box' },
    { id: 'pkGrid', title: '❤️ FF Likes' },
    { id: 'uidPkGrid', title: '💎 UID Topup (BD)' },
    { id: 'wmPkGrid', title: '📅 Weekly / Monthly Offer' },
    { id: 'wlPkGrid', title: '⚡ Weekly Lite' },
    { id: 'luPkGrid', title: '🚀 Level Up Pass' },
    { id: 'inPkGrid', title: '🌏 Indonesia Server' }
  ];

  function loadOrders() {
    try { const a = JSON.parse(fs.readFileSync(ordersPath, 'utf8')); return Array.isArray(a) ? a : []; }
    catch (_) { return []; }
  }
  function saveOrders(a) {
    fs.mkdirSync(dataDir, { recursive: true });
    const tmp = ordersPath + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(a, null, 2));
    fs.renameSync(tmp, ordersPath);
  }
  function getPackages() {
    let html = '';
    try { html = fs.readFileSync(htmlPath, 'utf8'); } catch (_) { return []; }
    return categories.map(cat => {
      const section = html.match(new RegExp('<div\\s+class="pk-grid"\\s+id="' + cat.id + '">([\\s\\S]*?)<\\/div>', 'i'));
      const packages = [];
      if (section) {
        const re = /<button\b[^>]*class="pk"[^>]*data-name="([^"]+)"[^>]*data-price="([0-9.]+)"[^>]*>/gi;
        let m;
        while ((m = re.exec(section[1]))) packages.push({ name: m[1].replace(/&amp;/g, '&'), price: Number(m[2]) });
      }
      return { id: cat.id, title: cat.title, packages };
    }).filter(x => x.packages.length);
  }
  const catalog = getPackages();

  async function api(method, payload) {
    const r = await fetch('https://api.telegram.org/bot' + token + '/' + method, {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify(payload || {}), signal: AbortSignal.timeout(35000)
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.description || 'Telegram API error');
    return j.result;
  }
  const send = (chatId, text, extra) => api('sendMessage', Object.assign({ chat_id: chatId, text, parse_mode: 'HTML', disable_web_page_preview: true }, extra || {}));
  const answer = (id, text) => api('answerCallbackQuery', { callback_query_id: id, text: text || '' }).catch(() => {});
  const homeKeyboard = { inline_keyboard: [
    [{ text: '🛍️ সব পণ্য দেখুন', callback_data: 'catalog' }],
    [{ text: '📦 আমার অর্ডার', callback_data: 'myorders' }, { text: '☎️ Support', url: 'https://t.me/rxtopuphelpline' }]
  ] };
  function esc(s) { return String(s).replace(/[&<>]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;'}[c])); }
  function mainMenu(chatId) {
    sessions.delete(String(chatId));
    return send(chatId, '🔥 <b>RX TOPUP</b>\nস্বাগতম! নিচের মেনু থেকে পণ্য বেছে অর্ডার করুন।', { reply_markup: homeKeyboard });
  }
  async function showCatalog(chatId) {
    const rows = catalog.map(c => [{ text: c.title, callback_data: 'cat:' + c.id }]);
    rows.push([{ text: '⬅️ মেইন মেনু', callback_data: 'home' }]);
    return send(chatId, '🛍️ <b>সব পণ্য</b>\nযে পণ্যটি অর্ডার করতে চান সেটি নির্বাচন করুন:', { reply_markup: { inline_keyboard: rows } });
  }
  async function showPackages(chatId, id) {
    const cat = catalog.find(x => x.id === id);
    if (!cat) return mainMenu(chatId);
    const rows = [];
    for (let i = 0; i < cat.packages.length; i += 2) {
      const row = [{ text: cat.packages[i].name + ' — ৳' + cat.packages[i].price, callback_data: 'pkg:' + id + ':' + i }];
      if (cat.packages[i + 1]) row.push({ text: cat.packages[i + 1].name + ' — ৳' + cat.packages[i + 1].price, callback_data: 'pkg:' + id + ':' + (i + 1) });
      rows.push(row);
    }
    rows.push([{ text: '⬅️ পণ্য তালিকা', callback_data: 'catalog' }]);
    return send(chatId, '<b>' + esc(cat.title) + '</b>\nআপনার প্যাকেজ নির্বাচন করুন:', { reply_markup: { inline_keyboard: rows } });
  }
  async function newOrder(chatId, user, catId, index) {
    const cat = catalog.find(x => x.id === catId);
    const item = cat && cat.packages[index];
    if (!cat || !item) return mainMenu(chatId);
    sessions.set(String(chatId), { step: 'uid', user: user, category: cat.title, item: item, chatId: chatId });
    return send(chatId, '✅ <b>' + esc(item.name) + '</b> — ৳' + item.price + '\n\nআপনার Free Fire Player UID লিখুন (কমপক্ষে ৬ সংখ্যা):', { reply_markup: { force_reply: true, selective: true } });
  }
  async function saveOrder(chatId, s, uid, method, txn) {
    const all = loadOrders();
    const id = 'RX' + Date.now().toString(36).toUpperCase();
    const u = s.user || {};
    const order = { id, userId: String(chatId), username: u.username || '', firstName: u.first_name || '', category: s.category, product: s.item.name, price: s.item.price, uid, payment: method, transactionId: txn, status: 'Pending', createdAt: new Date().toISOString() };
    all.unshift(order); saveOrders(all);
    sessions.delete(String(chatId));
    await send(chatId, '🎉 <b>অর্ডার জমা হয়েছে!</b>\nঅর্ডার: <code>' + id + '</code>\nপণ্য: ' + esc(order.product) + '\nUID: <code>' + esc(uid) + '</code>\nমূল্য: ৳' + order.price + '\nপেমেন্ট: ' + esc(method) + '\nTxn ID: <code>' + esc(txn) + '</code>\n\nঅ্যাডমিন যাচাই করে আপডেট জানাবেন।', { reply_markup: homeKeyboard });
    const userLine = (u.username ? '@' + u.username : (u.first_name || 'Telegram user'));
    await send(adminId, '🆕 <b>নতুন RX TOPUP অর্ডার</b>\nঅর্ডার: <code>' + id + '</code>\nকাস্টমার: ' + esc(userLine) + '\nChat ID: <code>' + chatId + '</code>\nক্যাটাগরি: ' + esc(order.category) + '\nপণ্য: ' + esc(order.product) + '\nUID: <code>' + esc(uid) + '</code>\nমূল্য: ৳' + order.price + '\nপেমেন্ট: ' + esc(method) + '\nTxn ID: <code>' + esc(txn) + '</code>', { reply_markup: { inline_keyboard: [[{ text: '✅ Accept', callback_data: 'decision:accept:' + id }, { text: '❌ Reject', callback_data: 'decision:reject:' + id }]] } });
  }
  async function onMessage(m) {
    const chatId = m.chat.id;
    const txt = String(m.text || '').trim();
    if (!txt) return;
    if (txt === '/start' || txt === '/menu') return mainMenu(chatId);
    if (txt === '/orders') return showMyOrders(chatId);
    if (String(chatId) === adminId && txt === '/admin') {
      const pending = loadOrders().filter(o => o.status === 'Pending');
      return send(chatId, 'Admin panel\nPending orders: ' + pending.length + (pending.length ? '\n' + pending.slice(0, 15).map(o => o.id + ' — ' + o.product + ' — ৳' + o.price).join('\n') : ''));
    }
    const s = sessions.get(String(chatId));
    if (!s) return send(chatId, 'মেনু থেকে পণ্য নির্বাচন করুন।', { reply_markup: homeKeyboard });
    if (s.step === 'uid') {
      if (!/^\d{6,20}$/.test(txt)) return send(chatId, 'সঠিক UID দিন (৬–২০ সংখ্যার হতে হবে)। আবার লিখুন:');
      s.uid = txt; s.step = 'payment'; sessions.set(String(chatId), s);
      return send(chatId, 'পেমেন্ট মাধ্যম নির্বাচন করুন:', { reply_markup: { inline_keyboard: [[{ text: 'bKash', callback_data: 'pay:bkash' }, { text: 'Nagad', callback_data: 'pay:nagad' }], [{ text: '⬅️ বাতিল', callback_data: 'home' }]] } });
    }
    if (s.step === 'txn') {
      if (txt.length < 5 || txt.length > 80) return send(chatId, 'সঠিক Transaction ID লিখুন (৫–৮০ অক্ষর)।');
      return saveOrder(chatId, s, s.uid, s.payment, txt);
    }
  }
  async function showMyOrders(chatId) {
    const list = loadOrders().filter(o => o.userId === String(chatId)).slice(0, 10);
    if (!list.length) return send(chatId, 'আপনার কোনো অর্ডার পাওয়া যায়নি।', { reply_markup: homeKeyboard });
    return send(chatId, '📦 <b>আপনার সাম্প্রতিক অর্ডার</b>\n\n' + list.map(o => '<code>' + esc(o.id) + '</code> — ' + esc(o.product) + ' ৳' + o.price + '\nস্ট্যাটাস: <b>' + esc(o.status) + '</b>').join('\n\n'), { reply_markup: homeKeyboard });
  }
  async function onCallback(q) {
    const chatId = q.message.chat.id;
    const data = String(q.data || '');
    await answer(q.id);
    if (data === 'home') return mainMenu(chatId);
    if (data === 'catalog') return showCatalog(chatId);
    if (data === 'myorders') return showMyOrders(chatId);
    if (data.startsWith('cat:')) return showPackages(chatId, data.slice(4));
    if (data.startsWith('pkg:')) {
      const p = data.split(':');
      return newOrder(chatId, q.from, p[1], Number(p[2]));
    }
    if (data.startsWith('pay:')) {
      const s = sessions.get(String(chatId));
      if (!s || s.step !== 'payment') return send(chatId, 'সেশন শেষ। /start দিয়ে আবার শুরু করুন।');
      s.payment = data === 'pay:bkash' ? 'bKash' : 'Nagad'; s.step = 'txn'; sessions.set(String(chatId), s);
      return send(chatId, 'আপনার ' + s.payment + ' পেমেন্ট সম্পন্ন করে Transaction ID লিখুন।\nপেমেন্ট নম্বর/নির্দেশনা ওয়েবসাইটের অফিসিয়াল নির্দেশনা থেকে যাচাই করুন।', { reply_markup: { force_reply: true, selective: true } });
    }
    if (data.startsWith('decision:')) {
      if (String(chatId) !== adminId) return send(chatId, 'এই অ্যাকশন শুধু অ্যাডমিন করতে পারবেন।');
      const p = data.split(':'); const status = p[1] === 'accept' ? 'Accepted' : 'Rejected'; const id = p[2];
      const all = loadOrders(); const o = all.find(x => x.id === id);
      if (!o) return send(chatId, 'অর্ডার পাওয়া যায়নি।');
      if (o.status !== 'Pending') return send(chatId, 'এই অর্ডারের সিদ্ধান্ত আগেই দেওয়া হয়েছে: ' + o.status);
      o.status = status; o.updatedAt = new Date().toISOString(); saveOrders(all);
      await send(o.userId, (status === 'Accepted' ? '✅ আপনার অর্ডার গ্রহণ করা হয়েছে।' : '❌ আপনার অর্ডার বাতিল করা হয়েছে।') + '\nঅর্ডার: <code>' + id + '</code>\nপণ্য: ' + esc(o.product) + '\nপ্রয়োজনে @rxtopuphelpline-এ যোগাযোগ করুন।');
      return send(chatId, 'অর্ডার ' + id + ' — ' + status);
    }
  }

  async function poll() {
    if (polling) return;
    polling = true;
    try {
      const updates = await api('getUpdates', { offset, timeout: 25, allowed_updates: ['message', 'callback_query'] });
      for (const u of updates) {
        offset = u.update_id + 1;
        try {
          if (u.message) await onMessage(u.message);
          if (u.callback_query) await onCallback(u.callback_query);
        } catch (e) { console.error('RX bot update error:', e.message); }
      }
    } catch (e) {
      console.error('RX bot polling error:', e.message);
      await new Promise(r => setTimeout(r, 5000));
    } finally {
      polling = false;
      setImmediate(poll);
    }
  }
  api('deleteWebhook', { drop_pending_updates: false }).then(() => {
    console.log('RX TOPUP Telegram bot polling started; catalog packages:', catalog.reduce((n, c) => n + c.packages.length, 0));
    poll();
  }).catch(e => console.error('RX bot startup error:', e.message));
};
